import static org.hamcrest.Matchers.*;
import io.restassured.response.Response;
import io.restassured.specification.RequestLogSpecification;
import io.restassured.specification.RequestSpecification;
import models.User;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static requests.LoginEndpoint.postLoginRequest;
import static requests.UserEndpoints.deleteUserRequest;
import static requests.UserEndpoints.postUserRequest;

public class POSTLoginTest extends TesteBase{

    private User validUser1;

    @BeforeClass
    public void generateTestData(){
        validUser1 = new User("Reginaldo","rdsj252@cesar.school", "123@2022A","false");
        postUserRequest(SPEC, validUser1);
    }

    @Test
    public void shouldReturnSucessMessageAndStatusCode200() {
        Response loginUserResponse = postLoginRequest((RequestSpecification) SPEC, validUser1);
        loginUserResponse.
                then().
                assertThat().
                statusCode(200).
                body("message",equalTo("Login realizado com sucesso")).
                body("authorization", notNullValue());
    }
    @AfterClass
    public void removeTestData(){
         deleteUserRequest(SPEC, validUser1);
    }
}
