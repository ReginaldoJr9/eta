import io.restassured.response.Response;
import models.Product;
import models.User;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static jdk.nashorn.internal.ir.debug.ObjectSizeCalculator.CurrentLayout.SPEC;
import static org.hamcrest.Matchers.equalTo;
import static requests.LoginEndpoint.postLoginRequest;
import static requests.ProductEndpoint.*;
import static requests.UserEndpoints.deleteUserRequest;
import static requests.UserEndpoints.postUserRequest;


public class PostProductTest extends TesteBase {
    private User NonAdminUser;
    private User AdminUser;
    private Product validProduct;
    private Product invalidProduct;

    @BeforeClass
    public void generateTestData() {
        NonAdminUser = new User("Reginaldo", "rdsj@cesar.school", "2020@", "false");
        AdminUser = new User("Regi Jr", "regi@email.com", "123Aa@", "true");;
        validProduct = new Product("Mouse", 28, "Mouse sem Fio", 10);
        invalidProduct = new Product("Monitor", 2300, "Monitor 24 polegadas",680);
        postUserRequest(SPEC, NonAdminUser);
        postLoginRequest(SPEC, NonAdminUser);
        postUserRequest(SPEC, AdminUser);
        postLoginRequest(SPEC, AdminUser);
    }

    @Test
    public void shouldReturnSuccessMessageNewProductAndStatusCode201() {
        Response postProductResponse = postProductRequest(SPEC, validProduct, AdminUser);
        postProductResponse.
                then().log().body().
                assertThat().
                statusCode(201).
                body("message", equalTo("Cadastro realizado com sucesso"));
    }

    @Test
    public void shouldReturnErrorExistingProductAndStatusCode401() {
        Response postProductResponse = postProductRequest(SPEC, invalidProduct, AdminUser);
        postProductResponse.
                then().
                assertThat().
                statusCode(400).
                body("message", equalTo("Já existe produto com esse nome"));
    }

    @Test
    public void shouldReturnErrorMessageAndStatus403() {
        Response ProductFailAdmin = postProductRequest(SPEC, validProduct, NonAdminUser);
        ProductFailAdmin.
                then().
                assertThat().
                statusCode(403).
                body("message", equalTo("Rota exclusiva para administradores"));
    }

    @AfterClass
    public void removeTestData() {
        deleteProductRequest(SPEC, validProduct, AdminUser);
        deleteUserRequest(SPEC, AdminUser);
        deleteUserRequest(SPEC, NonAdminUser);
    }

}